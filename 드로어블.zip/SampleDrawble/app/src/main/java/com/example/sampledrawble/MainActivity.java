package com.example.sampledrawble;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}

// TIL
// <드로어블 만들기>
// 뷰의 배경이미지
// 드로어블
// 상태 드로어블 만들기 <-- finger_drawable 참고
// 셰이프 드로어블 만들기 <--rect_drawable, back_drawable,  border_drawable 참고
