package org.techtown.receiver;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AutoPermissionsListener{

        @Override
        protected void onCreate (Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            AutoPermissions.Companion.loadAllpermissions(this, 101);
        }

        @Override
        public void onRequestPermissionResult(int requestCode, String[] permissions,
        int[] grantResults){
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            AutoPermissions.Companion.parsePermissions(this, requestCode, permissions, this);
        }

        @Override
        public void onDenied ( int requestCode, String[] permissions){
            Toast.makeText(this, "permissions denied : " + permissions.length, Toast.LENGTH_LONG).show();
        }

        @Override
        public void onGranted ( int requestCode, String[] permissions){
            Toast.makeText(this, "permissions granted : " + permissions.length, Toast.LENGTH_LONG).show();
        }
    }

