package org.techtown.samplervanimation

import android.app.ActivityOptions
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Pair
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.name_txt
import kotlinx.android.synthetic.main.activity_second.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        main_card.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)

            var options : ActivityOptions = ActivityOptions.makeSceneTransitionAnimation(
                this,
                Pair.create(name_txt, "nameTransition"),
                android.util.Pair.create(content_txt, "contentTransition"),
                android.util.Pair.create(profile_img, "imageTransition")
            )
            startActivity(intent, options.toBundle())
        }
    }
}