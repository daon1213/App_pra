package com.example.myapplication_java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //TIL
    // 화면 중앙에 있는 메시지 변경
    // 화면에 버튼 추가
    // 버튼을 눌렀을 때 메시지가 나타나게 하기
    // 여러 개의 버튼 추가하기
    // 디자인 화면에서 단말 변경하기
    // 새 버튼에 네이버 접속하기 기능과 전화 걸기 기능 추가하기

    public void onButton1Clicked(View v){
        Toast.makeText(this, "확인1 버튼이 눌렸어요.", Toast.LENGTH_LONG).show();
    }

    public void onButton2Clicked(View v){
        Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.naver.com"));
        startActivity(myIntent);
    }

    public void onButton3Clicked(View v){
        Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel : 010-9617-1696"));
        startActivity(myIntent);
    }

    // 오늘 배운 것의 알아둘 내용
    // 프로젝트 만들기
    // setContentView() : 화면에 무엇을 보여줄지 결정하는 함수(메서드)입니다.
    // R.layout.activity_main : 화면에 보여줄 대상이 되는 XML의 위치를 지정합니다.
    // /app/res/layout/activity_main.xml : 자바 소스에서 R.layout_main이라고 입력하여 가져올 수 있는 프로젝트 안의 파일, 화면 구성할 때 사용
    // text속성 : 화면에 보이는 글자를 변경할 때 사용하는 속성
    // onClick 속성 : 버튼을 클릭했을 때 어떤 메서드를 실행할 것인지 간단하게 지정할 수 있는 속성
    // Intent : 어떤 기능을 실행할 것인지 지정할 때 사용
    // Toast : 화면에 잠깐 보였다 없어지는 메시지를 간단하게 보여주고 싶을 때 사용
}