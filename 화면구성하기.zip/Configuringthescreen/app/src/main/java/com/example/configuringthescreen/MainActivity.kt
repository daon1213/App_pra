package com.example.configuringthescreen

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 액티비티
        // 액티비티 : 사용자가 직접보고 입력하는 화면을 담당하는 컴포넌트

        // 컨텍스트
        // 컨텍스트(Context)는 시스템을 사용하기 위한 정보와 도구가 담겨있는 클래스
        // 액티비티는 컨텍스트를 상속받아 구현

        // 컨텍스트의 종류

        // 애플리케이션 컨텍스트 : 애플리케이션과 관련된 핵심 기능을 담고 있는 클래스

        // 베이스 컨텍스트 : 안드로이드의 4대 메이저 컴포넌트( 액티비티, 서비스, 컨텐스 프로바이더, 브로드캐스트)의
        // 기반 클래스

        // 인텐트
        // 액티비티 실행을 위해 단순히 컨텍스트가 제공하는 메서드 호출하면 되는데, 실행할 액티비티가 명시된
        // 인텐트를 해당 메서드에 전달

        // 액티비티 실행을 위해 인텐트가 전달되는 과정
        // 1. 실행할 대상의 액티비티 이름과 전달할 데이터를 담아서 인텐트 생성
        // 2. 생성한 인텐트를 startActivity() 메서드에 담아서 호출하면 액티비티 매니저에 전달
        // 3. 액티비티 매니저는 인텐트를 분석해서 지정한 액티비티 실행
        // 4. 전달된 인텐트는 최종 목적지인 타깃 액티비티까지 전달됩니다.
        // 5. 타깃 액티비티에서는 전달받은 인텐트에 데이터가 있다면 이를 꺼내서 사용

        // 새 액티비티 만들고 실행하기

        // 메인 액티비티 화면 구성하기

        // 메인 액티비티에서 서브 액티비티 실행하기
        val intent = Intent(this, SubActivity::class.java) // 콜론이 2개. ::
        intent.putExtra("from1", "hello Bundle")
        intent.putExtra("from2", "2020")
        btnStart.setOnClickListener{ startActivityForResult(intent, 99)}

        // 액티비티 사이에 값 주고 받기
        // Activity 프로젝트에 이어서 계속

        // 메인 액티비티에서 값 돌려 받기

        // startActivityForResult 메서드 사용하기

        // 액티비티 생명주기

        // 액티비티 생명주기 메서드

        // onCreate() | 액티비티 상태 : 만들어짐 | 액티비티가 생성됩니다.
        // onStart() | 액티비티 상태 : 화면에 나타남 | 화면에 보이기 시작합니다.
        // onResume() | 액티비티 상태 : 화면에 나타남 | 실제 액티비티가 실행되고 있습니다.
        // onResume() | 액티비티 상태 : 현재 실행 중 | 실행 중
        // onPause() | 액티비티 상태 : 화면이 가려짐 | 액티비티 화면의 일부가 다른 액티비티에 가려집니다.
        // onStop() | 액티비티 상태 : 화면이 없어짐 | 다른 액티비티가 실행되어서 화면이 완전히 가려집니다.
        // onDestroy | 액티비티 상태 : 종료됨 | 종료됩니다.

//        override fun onPause() {
//            super.onPause()
//            videoView.stopPlayback()
//        }

        // 생명 주기 콜백의 이해
        // 액티비티는 인스턴스 생성과 동시에 생성과 관련된 생명 주기 메서드 순차적 호출
        // 그리고 finish() 메서드나 뒤로가기로 액티비티를 종료하면 소멸과 관련된 생명 주기 메서드가 순차적 호출

        // 액티비티 백스택
        // 백스택은 액티비티 또는 화면 컴포넌트를 담는 안드로이드의 저장공간

        // 테스크와 프로세스
        // 테스크는 애플리케이션에서 실행되는 프로세스를 관리하는 작업 단위

        // 간략한 카메라 앱 호출 코드

//        class Activity_B : AppCompatActivity(){
//            val REQ_CAMERA = 100
//        }
//        fun openCamera() {
//            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//            startActivityForResult(intent, REQ_CAMERA)
//        }

        // 액티비티 태스크 관리

        // 액티비티 태스크 관리 속성

        // taskAffinity
        // launchMode
        // allowTaskReparenting
        // clearTaskOnLaunch
        // alwaysRetainTaskState
        // finishOnTaskLaunch

        // 액티비티 태스크를 관리하는 또 다른 방법으로는 소스코드에서 startActivity() 메서드에 전달
        // 하는 플래그 값으로 태스크를 관리하는 방법
        // intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        // 보통 많이 사용하는 플래그
        // FLAG_ACTIVITY_MULTIPLE_TASK
        // FLAG_ACTIVITY_MULTIPLE_TASK
        // FLAG_ACTIVITY_NEW_TASK
        // FLAG_ACTIVITY_SINGLE_TOP
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (resultCode == Activity.RESULT_OK){
//            val message = data?.getStringExtra("returnValue")
//            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        // 이 코드를 if문을 사용해도 좋지만 케이스가 다양할 수 있으므로 when문으로 수정
            if (resultCode == Activity.RESULT_OK){
                when(requestCode){
                    99->{
                        val message = data?.getStringExtra("returnValue")
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    }
                }
            }
//        }
    }
}
