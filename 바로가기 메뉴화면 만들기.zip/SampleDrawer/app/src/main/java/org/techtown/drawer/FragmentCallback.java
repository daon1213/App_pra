package org.techtown.drawer;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public interface FragmentCallback {

    public void onFragmentSelected(int position, Bundle bundle);

}