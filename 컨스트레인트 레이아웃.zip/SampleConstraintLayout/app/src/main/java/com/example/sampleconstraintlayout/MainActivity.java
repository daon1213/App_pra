package com.example.sampleconstraintlayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //TIL
        // 레이아웃 기초 익히기
        // 가이드라인 사용하기
        // XML 원본에 추가된 속성 확인하기
        // 크기를 표시하는 단위와 마진
    }
}