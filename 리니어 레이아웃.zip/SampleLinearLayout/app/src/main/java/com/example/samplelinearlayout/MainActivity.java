package com.example.samplelinearlayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TIL
        // 레이아웃 익히기
        // 리니어 레이아웃 사용하기
        // 자바 코드에서 화면 구성하기
        // 화면 생성 과정 분석하기
        // 뷰 정렬하기
        // 뷰 정렬 속성 layout_gravity 자세히 알아보기
        // 내용물 정렬 속성 gravity 살펴보기
        // 폰트 크기 변경하기
        // 뷰의 마진과 패딩 설정하기
        // 여유 공간을 분할하는 layout_weight 속성

        // gravity 정렬 속성 값

        // top : 대상 객체 위쪽 끝 배치
        // bottom : 대상 객체 아래쪽 끝 배치
        // left : 대상 객체 왼쪽 끝 배치
        // right : 대상 객체 오른쪽 끝 배치
        // center_vertical : 대상 객체 수직 방향 중앙 배치
        // center_horizontal : 대상 객체 수평 방향의 중앙 배치
        // fill_vertical : 대상 객체 수직 방향 여유 공간 확대 채우기
        // fill_horizontal : 대상 객체 수평 방향 여유 공간 확대 채우기
        // center : 대상 객체 수직/수평 방향 중앙 배치
        // fill : 대상 객체 수직/수평 방향 여유 공간 확대 채우기
        // clip_vertical : 대상 객체의 상하 길이가 여유 공간보다 클 경우 남는 부분 잘라내기
        // clip_horizontal : 대상 객체의 좌우 길이가 여유 공간보다 클 경우 남는 부분 잘라내기

    }
}