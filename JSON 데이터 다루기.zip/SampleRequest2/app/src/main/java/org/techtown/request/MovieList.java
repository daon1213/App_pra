package org.techtown.request;

public class MovieList {
    MovieListResult boxOfficeResult;
}
