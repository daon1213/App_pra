package com.example.widgets

class Textview {
}

// TIL
// <텍스트뷰>
// 사용할 텍스트 정의 및 적용하기 : text
// 텍스트 색상 지정하기 : textColor
// 텍스트 크기 지정하기 : textSize
// 텍스트 스타일 지정하기 : textStyle <-- normal, bold, italic
// 입력 가능한 줄 수 설정하기 : maxLines, minLines
// 텍스트뷰 한 줄로 보이기 : singleLine
// 밑줄임 표시하기 : ellipsize <-- none, start, middle, end, marquee
// 텍스트 글꼴 지정하기 : fontFamily
// 비율로 글꼴 지정하기 : ems
// 텍스트뷰 높이 고정하기 : lines
// 텍스트 전체 길이 제한하기 : maxLength