package org.techtown.sampledatabinding

class ProfileData (
    var name : String,
    var age : Int
    )