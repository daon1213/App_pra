package org.techtown.movie;

public class MovieList {
    MovieListResult boxOfficeResult;
}
