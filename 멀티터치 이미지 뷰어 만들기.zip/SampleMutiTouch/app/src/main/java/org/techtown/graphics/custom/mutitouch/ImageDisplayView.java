package org.techtown.graphics.custom.mutitouch;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.Image;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public abstract class ImageDisplayView extends View implements View.OnClickListener {
    private static final String TAG = "ImageDisplayView";

    Context mContext;
    Canvas mCanvas;
    Bitmap mBitmap;
    Paint mPaint;

    int lastX;
    int lastY;

    Bitmap sourceBitmap;

    Matrix mMatrix;

    float sourceWidth = 0.0F;
    float sourceHeight = 0.0F;

    float bitmapCenterX;
    float totalScaleRatio;

    float scaleRatio;

    float displayWidth = 0.0F;
    float displayHeight = 0.0F;

    int displayCenterX = 0;

    int displayCenterY = 0;

    public float startX;
    public float startY;

    public static float MAX_SCALE_RATIO = 5.0F;
    public static float MIN_SCALE_RATIO = 0.1F;

    float oldDistance = 0.0F;

    int oldPointerCount = 0;
    boolean inScrolling = false;
    float distanceThreshold = 3.0F;
    private Object outScaleRatio;

    public ImageDisplayView(Context context) {
        super(context);

        mContext = context;

        init();
    }

    public ImageDisplayView(Context context, AttributeSet attrs){
        super(context, attrs);

        mContext = context;

        init();
    }

    private void init(){
        mPaint = new Paint();
        mMatrix = new Matrix();

        lastX = -1;
        lastY = -1;

        setOnTouchListener(this);
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh){
        if (w > 0 && h > 0){
            new Image(w, h);

            redraw();
        }
    }

    protected void onDraw(Canvas canvas){
        if (mBitmap != null){
            canvas.drawBitmap(mBitmap, 0, 0, null);
        }
    }

    public boolean onTouch(View v, MotionEvent ev){
        final int action = ev.getAction();

        int pointerCount = ev.getPointerCount();
        Log.d(TAG, "Pointer Count : " +pointerCount);

        switch (action){

            case MotionEvent.ACTION_DOWN:
                if (pointerCount == 1){
                    float curX = ev.getX();
                    float curY = ev.getY();

                    startX = curX;
                    startY = curY;
                } else if (pointerCount == 2){
                    oldDistance = 0.0F;
                    inScrolling = true;
                }

                return true;
            case MotionEvent.ACTION_MOVE:
                float outScaleRatio;
                if (pointerCount == 1){
                    if (inScrolling){
                        return true;
                    }

                    float curX = ev.getX();
                    float curY = ev.getY();

                    if (startX == 0.0F){

                        return true;
                    }

                    float offsetX = startX - curX;
                    float offsetY = startY - curY;

                    if (oldPointerCount == 2){

                    } else {
                        Log.d(TAG, "ACTION_MOVE : " +offsetX+ ", " +offsetY);
                        if (totalScaleRatio > 1.0F){
                            moveImage(-offsetX, -offsetY);
                        }

                        startX = curX;
                        startY = curY;
                    }
                } else if (pointerCount == 2) scaleImage(outScaleRatio);

                oldPointerCount = pointerCount;

                break;

                case MotionEvent.ACTION_UP:

                    if (pointerCount == 1){
                        float curX = ev.getX();
                        float curY = ev.getY();

                        float offsetX = startX - curX;
                        float offsetY = startY - curY;

                        if (oldPointerCount == 2){

                        } else {
                            moveImage(-offsetX, -offsetY);
                        }
                    } else inScrolling = false;
                    return true;
            default:

        }

        return true;
    }

    protected abstract void moveImage(float v, float v1);

    private void scaleImage(float inScaleRatio){
        Log.d(TAG, "scaleImage() called : " +inScaleRatio){

            mMatrix.postScale(inScaleRatio, inScaleRatio, bitmapCenterX, bitmapCenterY);
            mMatrix.postRotate(0);

            totalScaleRatio = totalScaleRatio * inScaleRatio;

            redraw();
        }

        private void moveImage(float offsetX, float offsetY){
            Log.d(TAG, "moveImage() called : " +offsetX+ ", " +offsetY);

            mMatrix.postTranslate(offsetX, offsetY);

            redraw();
        }
    }

    @Override
    public void onClick(View view) {

    }
}
