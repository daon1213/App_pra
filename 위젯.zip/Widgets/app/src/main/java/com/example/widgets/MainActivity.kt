package com.example.widgets

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}

// TIL
// <화면에 그려지는 디자인 요소 위젯>
// Common
// Text
// Buttons
// Widgets