package org.techtown.capture;

public class AutoPermissions {
}
