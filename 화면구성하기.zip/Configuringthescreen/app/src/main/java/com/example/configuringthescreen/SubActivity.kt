package com.example.configuringthescreen

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_sub.*

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)


        to1.text = intent.getStringExtra("from1")
        to2.text = "${intent.getIntExtra("from2", 0)}"
        btnClose.setOnClickListener{
            val returnIntent = Intent()
            returnIntent.putExtra("returnValue", editMessage.text.toString())
            setResult(Activity.RESULT_OK, returnIntent)
            finish()
        }


        // 텍스트뷰의 text 속성은 문자열만 받을 수 있는데 숫자 값이 입력되었으므로
        // 쌍따옴표로 감싸고 문자열 템플릿 이용하여 문자열로 변환


    }
}