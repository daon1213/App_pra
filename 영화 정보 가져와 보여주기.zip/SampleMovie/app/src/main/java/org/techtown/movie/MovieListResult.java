package org.techtown.movie;


import java.util.ArrayList;

public class MovieListResult {

    String boxofficeType;
    String showRange;

    ArrayList< org.techtown.request.Movie > dailyBoxOfficeList = new ArrayList < org.techtown.request.Movie >();
}
